The sketch will show circles. They should be read down and to the right. There are 7 circles in one column, and you read
it as one week. 

The colour represents the relative ranking. Green being the best and red being the worst. If you've seen health bars in 
video games, this is basically that. There is a gradient from green to red.

Size of circle depends on calories, so you will have the reddest and smallest circles as the lowest calories for the whole
of the data. Green circles will therefore be larger

The bars in the background also represent the maximum speed acheived when cycling. I was trying to break my own personal
best for the first couple weeks, so this should clue into their colour's meaning. I stopped after breaking 22 mph. Can you
see which week that is?

The bars should make it easier to see the weeks. The weeks are going from left to right, and the days are going downwards.

The values are shown in a relative format. This means that they are not showing what value they actually are, they are 
showing us how big they are in respect to the other values of the data set.
